import cv2
from ultralytics import YOLO
resolution = 96
usable_model = YOLO(r"./best.pt")

rus_names = {'angry': "яростный", 'fear': 'боится', 'happy': "счастливый", 'neutral': "нейтральный", 'sad': "грустный", 'surprise': "удивленный"}

face_cascade = cv2.CascadeClassifier('./haarcascade_frontalface_default.xml') 
cap = cv2.VideoCapture(0)

while cap.isOpened():
    ret, frame = cap.read()
    if ret:
        finded_faces = face_cascade.detectMultiScale(frame)

        for (x, y, w, h) in finded_faces:

            try:
                subframe = frame[x:x+w, y:y+h]
                subframe = cv2.resize(subframe, (resolution, resolution))
                prediction = usable_model.predict(subframe, verbose = False)[0]
                pred_id = prediction.probs.top1
                predicted_class = usable_model.names[pred_id]

                cv2.rectangle(frame,(x,y),(x+w,y+h),(255,255,0),2)
                cv2.putText(frame, rus_names[predicted_class], (x, y), cv2.FONT_HERSHEY_COMPLEX, 0.5, (255, 0, 0))
            except:
                pass
    
    cv2.imshow("win", frame)
    if cv2.waitKey(1) == ord('q'):
        break

cv2.destroyWindow("win")